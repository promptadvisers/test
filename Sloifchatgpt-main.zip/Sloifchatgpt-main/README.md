# Sloifchatgpt

## set up the python env
```
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## to run as gradio ui
```
python ui_sentiment_plus.py
```

## to run as command

### run_1note.py (sentiment + 7p + competitor)
```
python run_1note.py -openaikey sk-*** -input "Ved ikke om de har noget organisk affald... på deres hovedkontor har de et køkken, men det er en ekstern operatør der driver det... det er Michael Kjær fra driften, et fælles køkken med andre virksomheder.. Ring til ham om det. NCC bestemmer desuden selv om de skal have vores projekt med i loopet på dgnb point i byggeriet... i deres koncept udvikling...; De er ved at definere det og vi kan vende retur til Martin i Januar, hvor han ved hvem vi skal have møde med om det."
```

### run_file_batch.py (sentiment)
```
python run_file_batch.py -openaikey sk-*** -input test_notes.txt -batch 10
```

## to run as OpenFlow Agent
Before pack the code to openflow, need to modify OpenAI API Key in openflow_agent/sentimentagent/util_*.py. Please remember to change the below line (a fake key) in each util_*.py to a real key.
```
key = "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"
```
